﻿using DemoApp.CustomException;
using DemoApp.Models.Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DemoApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MedicineController : ControllerBase
    {
        private readonly MedicalStore _medicalStore;

        public MedicineController()
        {
            _medicalStore = new MedicalStore();
        }

        [HttpGet]
        public ActionResult<List<Medicine>> GetMedicines()
        {
            string filePath = "medicines.txt";
            var medicines = _medicalStore.GetMedicines(filePath);

            if (medicines.Count == 0)
            {
                throw new NoMedicineFoundException("No medicines to order at present");
            }

            return medicines;
        }

        [HttpGet]
        [Route("purchaseAmount")]
        public ActionResult<double> GetPurchaseAmount()
        {
            string filePath = "medicines.txt";
            var medicines = _medicalStore.GetMedicines(filePath);

            if (medicines.Count == 0)
            {
                throw new NoMedicineFoundException("No medicines to order at present");
            }

            double totalPurchaseAmount = _medicalStore.GetPurchaseAmount(medicines);
            return totalPurchaseAmount;
        }
    }
}
