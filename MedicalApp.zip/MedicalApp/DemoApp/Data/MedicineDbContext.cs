﻿using DemoApp.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace DemoApp.Data
{
    public class MedicineDbContext : DbContext
    {
        public MedicineDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions)
        {
            
        }

        public DbSet<Medicine> Medicines { get; set; }
    }
}
