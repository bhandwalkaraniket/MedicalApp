﻿namespace DemoApp.CustomException
{
    public class NoMedicineFoundException : Exception
    {
        public NoMedicineFoundException(string message) : base(message)
        {
        }
    }

}
