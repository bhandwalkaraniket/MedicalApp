﻿using DemoApp.Models.Domain;

namespace DemoApp
{
    public class MedicalStore
    {
        public List<Medicine> GetMedicines(string filePath)
        {
            List<Medicine> medicines = new List<Medicine>();

            try
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    int medicineId = int.Parse(parts[0]);
                    string medicineName = parts[1];
                    decimal price = decimal.Parse(parts[2]);
                    int quantity = int.Parse(parts[3]);

                    // Check the conditions and add the medicine to the list if it meets the criteria
                    if (quantity <= 20 || price < 500)
                    {
                        medicines.Add(new Medicine
                        {
                            MedicineId = medicineId,
                            MedicineName = medicineName,
                            Price = price,
                            Quantity = quantity
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
            }

            return medicines;
        }

        public double GetPurchaseAmount(List<Medicine> medicines)
        {
            double totalPurchaseAmount = 0;

            foreach (var medicine in medicines)
            {
                totalPurchaseAmount += (double)(medicine.Price * medicine.Quantity);
            }

            return totalPurchaseAmount;
        }
    }

}
